// Geoffrey Hicks
// Fall 2017 ITP 220 - V1 Java Programming II
// Airplane Simulation Class Project


package McawsCheckPoint4;


public class Driver { // this is the driver class. Used to start the program. 
    
    public static void main (String[] args){
        Reservation.setCount(UsefulMethods.getStartResNum()); // grabs the latest reservation number from the database, then stores it in the java program so it can be used 
        Menu temp = new Menu();
       
        temp.setVisible(true);
    }
    
}

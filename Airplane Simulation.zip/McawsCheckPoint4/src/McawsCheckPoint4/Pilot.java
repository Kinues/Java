//this class deals with pilot information

package McawsCheckPoint4;

/**
 *
 * @author geohe
 */

//we will keeep an array list of pilots
public class Pilot {
    private static int count = 1;
    private int pilotNum = 0; //pilot identifier
    private String pilotName;
    
    
    public Pilot(String myPilotName){
        pilotName = myPilotName;
        
        pilotNum = count++;
    }

    public int getPilotNum() {
        return pilotNum;
    }

    public void setPilotNum(int pilotNum) {
        this.pilotNum = pilotNum;
    }
   

    public String getPilotName() {
        return pilotName;
    }

    public void setPilotName(String pilotName) {
        this.pilotName = pilotName;
    }

}

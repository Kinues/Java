//this class is used to store information about flight, as well as methods that deal with the actual flight itself

package McawsCheckPoint4;

import java.util.ArrayList;

/**
 *
 * @author geohe
 */
public class FlightInformation { // holds information about flight
    
    private static int count = 1;
    private int flightNum; 
    private String flightName;
    private String flightCode;
    private String flightDate;
    private String flightTime;
    private String flightRoute;
    //private Pilot pilot;
    private int pilotNum;
    
    

    
    
    public FlightInformation(String myFlightName, String myFlightCode, String myFlightDate, String myFlightTime, String myFlightRoute, int myPilotNum){
        flightName = myFlightName;
        flightCode = myFlightCode;
        flightDate = myFlightDate;
        flightTime = myFlightTime;
        flightRoute = myFlightRoute;
        pilotNum = myPilotNum;
        flightNum = count++;
        
        
    }

    public int getFlightNum() { //grabs flight number
        return flightNum;
    }

    public void setFlightNum(int flightNum) { // sets flight number
        this.flightNum = flightNum;
    }


    public void setFlightCode(String flightCode) {
        this.flightCode = flightCode;
    }

    public String getFlightDate() {
        return flightDate;
    }

    public void setFlightDate(String flightDate) {
        this.flightDate = flightDate;
    }

    public String getFlightTime() {
        return flightTime;
    }

    public void setFlightTime(String flightTime) {
        this.flightTime = flightTime;
    }

    public String getFlightRoute() {
        return flightRoute;
    }

    public void setFlightRoute(String flightRoute) {
        this.flightRoute = flightRoute;
    }

   
}

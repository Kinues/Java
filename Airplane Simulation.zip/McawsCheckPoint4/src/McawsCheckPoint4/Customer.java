//this class is used to deal with customers
package McawsCheckPoint4;
import java.util.Random;
/**
 *
 * @author geohe
 */

//we will keep an array list of customers
public class Customer {

    private static int count = 1;
    private int custNum; // customer identifier
    private String custName;
    private String custAddress;
    private String custPhone;
    private Random rand = new Random();
    

   
   
    public Customer(String myCustName, String myCustAddress,  String myCustPhone){
        custName = myCustName;
        custAddress = myCustAddress;
        custPhone = myCustPhone;        
        

        custNum = count++;
    }
    
    
    

    public int getCustNum() {
        return custNum;
    }

    public void setCustNum(int custNum) {
        this.custNum = custNum;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getCustAddress() {
        return custAddress;
    }

    public void setCustAddress(String custAddress) {
        this.custAddress = custAddress;
    }

    public String getCustPhone() {
        return custPhone;
    }

    public void setCustPhone(String custPhone) {
        this.custPhone = custPhone;
    }
    
    
    
}

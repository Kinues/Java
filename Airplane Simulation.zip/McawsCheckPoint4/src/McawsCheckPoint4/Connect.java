//This class is used to connect to database


package McawsCheckPoint4;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 *
 * @author geohe
 */
public class Connect {
     private static Connection con;
    private static Statement stmt;

 

    private static Scanner scan = new Scanner(System.in);

    /**
     * Check to see if a database connection has been established. If not create
     * one.
     *
     * @see #createConnection()
     */
    public static void checkConnect() {
        if (con == null) {
            con = createConnection();
        }
        if (stmt == null) {
            try {
                stmt = con.createStatement();
            } catch (SQLException e) {
                System.out.println("SQL Error: Cannot create the statement.");
            }
        }
    }

    /**
     * Close the database connection if it exists.
     *
     */
    public static void closeConnection() {
        if (con != null) {
            try {
                con.close();
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("SQL Exception occurred when closing the connection.");
            }
        }
    }

    /**
     * Creates a database connection after prompting the user for the user
     * account and password for the MySQL database server. Then prompts for the
     * name of the database to use.
     * <p>
     * In the event of an unrecoverable exception, this will attempt to save
     * existing data in memory to disk using the <code>PetStoreDriver</code>
     * <code>writeRecoveryFilesAndShutDown</code> method.
     *
     * @return a connection to the MySQL database server
     * @see JDBCConnection#connect(int, String, String)
     * @see PetStoreDriver#writeRecoveryFilesAndShutDown()
     */
    public static Connection createConnection() {
        String user = "ITP220";
        String pass = "ITP220";
        try {
            //System.out.println("What is the username for the database?");
            //String user = scan.nextLine();
            //System.out.println("What is the password?");
            //String pass = scan.nextLine();
            con = JDBCConnection.connect(JDBCConnection.MYSQLLOCAL, user, pass);
        } catch (IllegalStateException e) {
            // Scanner is closed. Open a new one.
            scan = new Scanner(System.in);
        } catch (NoSuchElementException e) {
            // If the person enters CTRL-Z this exception occurs.
            System.out.println("Wrong move buddy!");
        }
        return con;
    }
    
       public static Connection getCon() {
        return con;
    }

    public static void setCon(Connection con) {
        Connect.con = con;
    }

    public static Statement getStmt() {
        return stmt;
    }

    public static void setStmt(Statement stmt) {
        Connect.stmt = stmt;
    }

}

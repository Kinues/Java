//this class stores reservation data


package McawsCheckPoint4;

/**
 *
 * @author vwstudent
 */
public class Reservation {

  
    
    private static int count = 1;
    private int resNum; 
    private int flightNumber;
    private String fClass;
    private double flightCost;
    private int custNum;
    private int groupNum;

    public int getGroupNum() {
        return groupNum;
    }

    public void setGroupNum(int groupNum) {
        this.groupNum = groupNum;
    }
    
    public Reservation(int myCustNum, String myFClass, double myFlightCost, int myFlightNumber, int myGroupNum){
        custNum = myCustNum;
        fClass = myFClass;
        flightCost = myFlightCost;
        flightNumber = myFlightNumber;
        groupNum = myGroupNum;
        count++;
        resNum = count;
        
    }

    public String getfClass() {
        return fClass;
    }

    public void setfClass(String fClass) {
        this.fClass = fClass;
    }

    public int getResNum() {
        return resNum;
    }

    public void setResNum(int resNum) {
        this.resNum = resNum;
    }

    public int getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber) {
        this.flightNumber = flightNumber;
    }

    

    public double getFlightCost() {
        return flightCost;
    }

    public void setFlightCost(double flightCost) {
        this.flightCost = flightCost;
    }

    public int getCustNum() {
        return custNum;
    }

    public void setCustNum(int custNum) {
        this.custNum = custNum;
    }

      public static int getCount() {
        return count;
    }

    public static void setCount(int count) {
        Reservation.count = count;
    }
  
}

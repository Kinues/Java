//this class is used to prime data

package McawsCheckPoint4;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author geohe
 */
public class UsefulMethods { //contains methods used often throughout program
    
   
    
    public static void addCustomer(String name, String address, String phone){ // adds customer to database
        try {
            Connect.checkConnect();
            
            Connect.getStmt().executeUpdate("call addCust ('" + name + "', '" + address + "', '" + phone + "')");
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    public static int checkCustomerNumber(int myCustNum){ //used to verify that customer is in database
        try {
            Connect.checkConnect();
            
            ResultSet rs;
            
            rs = Connect.getStmt().executeQuery("call getCustId()");
            
            while(rs.next()){
                if (rs.getInt("custId") == myCustNum){
                    return myCustNum;
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }
    
    public static int getCustomerNumber (String myCustName){ // used to retrieve customer number based off customer name
        try {
            Connect.checkConnect();
            
            ResultSet rs;
            
            rs = Connect.getStmt().executeQuery("call getSpecificCustId('" + myCustName + "')");
            while (rs.next()){
                return rs.getInt("custId");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }
    
    public static int checkFlightMatch(String flightDate, String flightTime, String flightRoute){ // used to check and see if the flight information matches any of the flights in the database
        try {
            Connect.checkConnect();
            
            ResultSet rs;
            
            rs = Connect.getStmt().executeQuery("call getFlightMatchFlightId('" + flightDate + "', '" + flightTime + "', '" + flightRoute + "')");
            
            while (rs.next()){
                return rs.getInt("flightId");
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }
    
    public static void addReservation(Reservation tempRes, int seatNumber){ // used to add a reservation to database
        try {
            Connect.checkConnect();
            int currentSeatNum = 0;
            int pastSeatNum = 0;
            Integer[] tempFirstClass = {0,0,0,0};
            Integer[] tempEconomyClass = {0,0,0,0,0,0,0,0};
            
            
            
            ResultSet rs;

            if (tempRes.getfClass().equalsIgnoreCase("first class")) {
                rs = Connect.getStmt().executeQuery("call getResSeatNum(" + tempRes.getFlightNumber() + ", '" + tempRes.getfClass() + "')");

                while (rs.next()) {
                    tempFirstClass[rs.getInt("seatNumber") - 1] = rs.getInt("seatNumber");
                }

                A:
                for (int i = 0; i < tempFirstClass.length; i++) {
                    if (tempFirstClass[i] == 0) {
                        seatNumber = i + 1;
                        break A;
                    }
                }

            }
            else if (tempRes.getfClass().equalsIgnoreCase("economy")){
                rs = Connect.getStmt().executeQuery("call getResSeatNum(" + tempRes.getFlightNumber() + ", '" + tempRes.getfClass() + "')");

                while (rs.next()) {
                    tempEconomyClass[rs.getInt("seatNumber") - 1] = rs.getInt("seatNumber");
                }

                A:
                for (int i = 0; i < tempEconomyClass.length; i++) {
                    if (tempEconomyClass[i] == 0) {
                        seatNumber = i + 1;
                        break A;
                    }
                }
            }
            Connect.getStmt().executeUpdate("call resInsertion(" + tempRes.getResNum() + ", " + tempRes.getCustNum() + ", '" + tempRes.getfClass() + "', " + tempRes.getFlightCost() + ", " + tempRes.getFlightNumber() + ", " + tempRes.getGroupNum() + ", " + seatNumber + ")");
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static boolean checkIfFull(int myFlightNumber, String fClass, int reservationCount){ // checks to see if flight is already full
        try {
            Connect.checkConnect();
            ResultSet rs;
            
            rs = Connect.getStmt().executeQuery("call checkIfFull(" + myFlightNumber + ", '" + fClass + "')");
            while (rs.next()){
                if (fClass.equalsIgnoreCase("economy")){
                    if ((reservationCount + rs.getInt("seatCount")) > 8)
                        return true;  
                }
                else if (fClass.equalsIgnoreCase("first class")){
                    if ((reservationCount + rs.getInt("seatCount")) > 4)
                        return true;
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
   
    public static int isSeatingProblem(int flightNumber, String fClass, int groupNumber, int partyCount, ArrayList<Integer> myGroupNum) { // checks to see if there is a seating issue on the flight
        try {
            Connect.checkConnect();
            int count = 0;
            Integer[] tempFirstClass = {0, 0, 0, 0};
            Integer[] tempFirstClassGroupNum = {0, 0, 0, 0};
            Integer[][] tempFirstClass2D = new Integer[2][2];
            Integer[] tempEconomyClass = {0, 0, 0, 0, 0, 0, 0, 0};
            Integer[] tempEconomyClassGroupNum = {0, 0, 0, 0, 0, 0, 0, 0};
            Integer[][] tempEconomyClass2D = new Integer[2][4];

            
            ResultSet rs;
            
            if (fClass.equalsIgnoreCase("first class")) {
                rs = Connect.getStmt().executeQuery("call getResSeatNum(" + flightNumber + ", '" + fClass + "')");
                while (rs.next()) {
                    tempFirstClass[rs.getInt("seatNumber") - 1] = rs.getInt("seatNumber");
                }

                for (int l = 0; l < tempFirstClass.length; l++) {
                    rs = Connect.getStmt().executeQuery("call getGroupAndSeat(" + flightNumber + ", " + groupNumber + ")");
                    while (rs.next()) {
                        if (rs.getInt("seatNumber") == tempFirstClass[l]) {
                            tempFirstClassGroupNum[l] = rs.getInt("groupNumber");
                        }
                    }
                }

                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        if (count == tempFirstClassGroupNum.length) {
                            break;
                        }
                        tempFirstClass2D[i][j] = tempFirstClassGroupNum[count];
                        count++;
                    }
                }

                if (isSeatingProbF(groupNumber, partyCount, tempFirstClass2D) == true) {
                   

                    JTextField choice = new JTextField(5);

                    JPanel myPanel = new JPanel();
                    myPanel.add(new JLabel("You won't be seated next to each other. Do you still want to continue? (yes/no): "));
                    myPanel.add(choice);

                    int result = JOptionPane.showConfirmDialog(null, myPanel,
                            "ERROR!!!!", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                    }

                    if (choice.getText().equalsIgnoreCase("yes")) {
                        return 1;
                    } else if (choice.getText().equalsIgnoreCase("no")) {
                        Reservation.setCount(Reservation.getCount() - partyCount);
                        myGroupNum.set(0, myGroupNum.get(0) - 1);
                        Connect.getStmt().executeUpdate("call deleteRes(" + groupNumber + ")");
                        return 0;

                    }
                }
            }
            else if (fClass.equalsIgnoreCase("economy")){
                rs = Connect.getStmt().executeQuery("call getResSeatNum(" + flightNumber + ", '" + fClass + "')");
                while (rs.next()) {
                    tempEconomyClass[rs.getInt("seatNumber") - 1] = rs.getInt("seatNumber");
                }

                for (int l = 0; l < tempEconomyClass.length; l++) {
                    rs = Connect.getStmt().executeQuery("call getGroupAndSeat(" + flightNumber + ", " + groupNumber + ")");
                    while (rs.next()) {
                        if (rs.getInt("seatNumber") == tempEconomyClass[l]) {
                            tempEconomyClassGroupNum[l] = rs.getInt("groupNumber");
                        }
                    }
                }

                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 4; j++) {
                        if (count == tempEconomyClassGroupNum.length) {
                            break;
                        }
                        tempEconomyClass2D[i][j] = tempEconomyClassGroupNum[count];
                        count++;
                    }
                }

                if (isSeatingProbE(groupNumber, partyCount, tempEconomyClass2D) == true) {
              

                    JTextField choice = new JTextField(5);

                    JPanel myPanel = new JPanel();
                    myPanel.add(new JLabel("You won't be seated next to each other. Do you still want to continue? (yes/no): "));
                    myPanel.add(choice);

                    int result = JOptionPane.showConfirmDialog(null, myPanel,
                            "ERROR!!!!", JOptionPane.OK_CANCEL_OPTION);
                    if (result == JOptionPane.OK_OPTION) {
                    }

                    if (choice.getText().equalsIgnoreCase("yes")) {
                        return 1;
                    } else if (choice.getText().equalsIgnoreCase("no")) {
                        Reservation.setCount(Reservation.getCount() - partyCount);
                        myGroupNum.set(0, myGroupNum.get(0) - 1);
                        Connect.getStmt().executeUpdate("call deleteRes(" + groupNumber + ")");
                        return 0;

                    }
                    
                }
            }


            
            

             
             
             
            
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }

        return 0;
    }
    
    public static boolean isSeatingProbF(int groupNum, int custListSize, Integer[][] tempFirstClass) { // checks to see if passengers are seated next to each other in first class
        
        int problemCount = 0; //how close statement is to true
        int notProblemCount = 0; //how close statement is to false
        int x1Count = 0;
        int x2Count = 0;
        
        if (custListSize == 1)
            return false;

        for (int i = 0; i < tempFirstClass.length; i++) {
            for (int j = 0; j < tempFirstClass[i].length; j++) {
                
                if ((tempFirstClass[i][j] != 0)){ 
                        if (tempFirstClass[i][j] == groupNum){
                            if (i == 0) {
                                x1Count++;
                            } else if (i == 1) {
                                x2Count++;
                            }
                        }
                }
                
                if ((j == 1)) {
                    if ((tempFirstClass[i][j] != 0) && (tempFirstClass[i][0] != 0)) {
                        if (tempFirstClass[i][j] == groupNum) {
                            if (tempFirstClass[i][j] == tempFirstClass[i][0]) {
                                notProblemCount++;
                            } else {
                                problemCount++;
                            }
                        }
                    }
                } else if ((tempFirstClass[i][j] != 0) && (tempFirstClass[i][j + 1] != 0)) {
                    if (tempFirstClass[i][j] == groupNum) {
                        if (tempFirstClass[i][j] == tempFirstClass[i][j + 1]) {
                            notProblemCount++;
                        } else {
                            problemCount++;
                        }
                    }

                }
            }
        }
        
        
        if ((x1Count + x2Count) == 4)
            return true;
        else if (((x1Count > 0) && (x2Count != 0)) || ((x2Count > 0) && (x1Count != 0)))
            return true;   
        else if (problemCount > 0)
            return true;
        else
            return false;
                   
    }
    
    public static boolean isSeatingProbE(int groupNum, int custListSize, Integer[][] tempEconomyClass) { // checks to see if passengers are seated next to each other in economy class
        
        int problemCount = 0; //how close statement is to true
        int notProblemCount = 0; //how close statement is to false
        int x1Count = 0;
        int x2Count = 0;
        
        if (custListSize == 1)
            return false;

        for (int i = 0; i < tempEconomyClass.length; i++) {
            for (int j = 0; j < tempEconomyClass[i].length; j++) {
                
                if ((tempEconomyClass[i][j] != 0)){ 
                        if (tempEconomyClass[i][j] == groupNum){
                            if (i == 0) {
                                x1Count++;
                            } else if (i == 1) {
                                x2Count++;
                            }
                        }
                }
                
                if ((j == 3)) {
                    if ((tempEconomyClass[i][j] != 0) && (tempEconomyClass[i][2] != 0)) {
                        if (tempEconomyClass[i][j] == groupNum) {
                            if (tempEconomyClass[i][j] == tempEconomyClass[i][2]) {
                                notProblemCount++;
                            } else {
                                problemCount++;
                            }
                        }
                    }
                } else if ((tempEconomyClass[i][j] != 0) && (tempEconomyClass[i][j + 1] != 0)) {
                    if (tempEconomyClass[i][j] == groupNum) {
                        if (tempEconomyClass[i][j] == tempEconomyClass[i][j + 1]) {
                            notProblemCount++;
                        } else {
                            problemCount++;
                        }
                    }

                }
            }
        }
        
       
        if ((x1Count + x2Count) == 8)
            return true;
        else if (((x1Count > 0) && (x2Count != 0)) || ((x2Count > 0) && (x1Count != 0)))
            return true;   
        else if (problemCount > 0)
            return true;
        else
            return false;
                   
    }
    
    
    
    
    
    
    public static void addReservation(int resChoice){ // adds deleted reservation
        int counter = 0;
        try {
            
            Connect.checkConnect();
            
            ResultSet rs;
            
            int custNumber = 0;
            double flightCost = 0;
            int flightNumber = 0;
            String flightSeat = null;
            int groupNumber = 0;
            int reservationNum = 0;
            int seatNumber = 0;
            
            rs = Connect.getStmt().executeQuery("call displayRes(" + resChoice + ")");
            
            
            
            
            while (rs.next()){
                
                custNumber = rs.getInt("custNumber");
                flightCost = rs.getDouble("flightCost");
                flightNumber = rs.getInt("flightNumber");
                flightSeat = rs.getString("flightSeat");
                groupNumber = rs.getInt("groupNumber");
                reservationNum = rs.getInt("reservationNum");
                seatNumber =  rs.getInt("seatNumber");
                
               counter++;
            }
            
            if (counter > 0){
                Connect.getStmt().executeUpdate("call updateDeletedRes(" + custNumber + ", " + flightCost + ", " + flightNumber + ", '" + flightSeat + "', " + groupNumber + ", " + reservationNum + ", " + seatNumber + ")");
                 
            }
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
   
    
    public static void showSeatsEClass(int flightChoice){ // displays economy class seats
        try {
            Connect.checkConnect();
            
            ResultSet rs;
            Integer[] economyClass = {0, 0, 0, 0, 0, 0, 0, 0};
            Integer[][] tempEconomyClass2D = new Integer[2][4];
          
            int count = 0;
            
            
            rs = Connect.getStmt().executeQuery("call getResCustSeatEC(" + flightChoice + ")");
            while (rs.next()){
                for (int i = 0; i < economyClass.length; i++){
                    if ((i + 1) == rs.getInt("seatNumber")){
                        economyClass[i] = rs.getInt("custNumber");
                    }
                }
            }
     
            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 4; j++) {
                    if (count == economyClass.length) {
                        break;
                    }
                    tempEconomyClass2D[i][j] = economyClass[count];
                    count++;
                }
            }

            for (int i = 0; i < tempEconomyClass2D.length; i++) {
                for (int j = 0; j < tempEconomyClass2D[i].length; j++) {
                }
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static int getStartResNum(){ //used to get beginning reservation number, so program can be run multiple times
        
        try {
            Connect.checkConnect();           
            ResultSet rs;
            int maxRes;
            
            rs = Connect.getStmt().executeQuery("select max(reservationNum) as max from reservation");
            
            while (rs.next()){
                return rs.getInt("max");
            }
            
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }
    
    public static int getStartGroupNum(){ // used to get starting group number, so program can be run multiple times
        try {
            Connect.checkConnect();
            
            ResultSet rs;
            int maxResNormal = 0;
            int maxResDeleted = 0;
            
            rs = Connect.getStmt().executeQuery("select max(groupNumber) as max from reservation");
            
            while (rs.next()){
                maxResNormal = rs.getInt("max");
            }
            
            rs = Connect.getStmt().executeQuery("select max(groupNumber) as max from deletedres");
            
            while (rs.next()){
                maxResDeleted = rs.getInt("max");
            }
            
            if (maxResDeleted > maxResNormal)
                return maxResDeleted;
            else
                return maxResNormal;
            
            
        } catch (SQLException ex) {
            Logger.getLogger(UsefulMethods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return 0;
    }
    
        
    
}

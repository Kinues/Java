package McawsCheckPoint4;


public class Menu extends javax.swing.JFrame { // this class is used to display menu items

  
    public Menu() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        printCust = new javax.swing.JButton();
        createReservation = new javax.swing.JButton();
        printCustByNum = new javax.swing.JButton();
        printFlightIncome = new javax.swing.JButton();
        showSeats = new javax.swing.JButton();
        removeRes = new javax.swing.JButton();
        printPilotSchedule = new javax.swing.JButton();
        printCustRes = new javax.swing.JButton();
        searchRes = new javax.swing.JButton();
        searchDeletedRes = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        exit = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        printCust.setText("Print Cust Info");
        printCust.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printCustActionPerformed(evt);
            }
        });

        createReservation.setText("Create Reservations");
        createReservation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createReservationActionPerformed(evt);
            }
        });

        printCustByNum.setText("Print Customer by their number");
        printCustByNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printCustByNumActionPerformed(evt);
            }
        });

        printFlightIncome.setText("Print Gross Flight Income");
        printFlightIncome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printFlightIncomeActionPerformed(evt);
            }
        });

        showSeats.setText("Show Seats");
        showSeats.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showSeatsActionPerformed(evt);
            }
        });

        removeRes.setText("Remove Reservation");
        removeRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeResActionPerformed(evt);
            }
        });

        printPilotSchedule.setText("Print Pilot Schedule");
        printPilotSchedule.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printPilotScheduleActionPerformed(evt);
            }
        });

        printCustRes.setText("Print Customer Reservation");
        printCustRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printCustResActionPerformed(evt);
            }
        });

        searchRes.setText("Search Reservations");
        searchRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchResActionPerformed(evt);
            }
        });

        searchDeletedRes.setText("Search Deleted Reservations");
        searchDeletedRes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchDeletedResActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("Menu");

        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Simulation");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Airplane");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(showSeats)
                    .addComponent(removeRes)
                    .addComponent(printPilotSchedule)
                    .addComponent(printCustRes)
                    .addComponent(searchRes)
                    .addComponent(searchDeletedRes)
                    .addComponent(printFlightIncome)
                    .addComponent(printCustByNum)
                    .addComponent(createReservation)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(printCust)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)))
                    .addComponent(exit))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(printCust)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(createReservation)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printCustByNum)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printFlightIncome)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(showSeats)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(removeRes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printPilotSchedule)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(printCustRes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchRes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(searchDeletedRes)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(exit))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void printCustActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printCustActionPerformed
        printCustInfo pci = new printCustInfo();
        pci.setVisible(true);
        
    }//GEN-LAST:event_printCustActionPerformed

    private void createReservationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createReservationActionPerformed
      RealBookFlight bookFlight = new RealBookFlight();
      bookFlight.setVisible(true);
    }//GEN-LAST:event_createReservationActionPerformed

    private void printCustByNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printCustByNumActionPerformed
        PrintCustByNum pcbn = new PrintCustByNum();
        pcbn.setVisible(true);
    }//GEN-LAST:event_printCustByNumActionPerformed

    private void printFlightIncomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printFlightIncomeActionPerformed
        FlightIncome fi = new FlightIncome();
        fi.setVisible(true);
    }//GEN-LAST:event_printFlightIncomeActionPerformed

    private void showSeatsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showSeatsActionPerformed
        showSeats ss = new showSeats();
        ss.setVisible(true);
    }//GEN-LAST:event_showSeatsActionPerformed

    private void removeResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeResActionPerformed
        RemoveReservation rr = new RemoveReservation();
        rr.setVisible(true);
    }//GEN-LAST:event_removeResActionPerformed

    private void printPilotScheduleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printPilotScheduleActionPerformed
        PilotSchedule ps = new PilotSchedule();
        ps.setVisible(true);
    }//GEN-LAST:event_printPilotScheduleActionPerformed

    private void printCustResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printCustResActionPerformed
        PrintCustReservation pcr = new PrintCustReservation();
        pcr.setVisible(true);
    }//GEN-LAST:event_printCustResActionPerformed

    private void searchResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchResActionPerformed
        SearchReservation sr = new SearchReservation();
        sr.setVisible(true);
    }//GEN-LAST:event_searchResActionPerformed

    private void searchDeletedResActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchDeletedResActionPerformed
        SearchDeletedReservations sdr = new SearchDeletedReservations();
        sdr.setVisible(true);
    }//GEN-LAST:event_searchDeletedResActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitActionPerformed

    
    public static void createReservation2(){
    RealBookFlight bookFlight = new RealBookFlight();
      bookFlight.setVisible(true);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Menu().setVisible(true);               
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton createReservation;
    private javax.swing.JButton exit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton printCust;
    private javax.swing.JButton printCustByNum;
    private javax.swing.JButton printCustRes;
    private javax.swing.JButton printFlightIncome;
    private javax.swing.JButton printPilotSchedule;
    private javax.swing.JButton removeRes;
    private javax.swing.JButton searchDeletedRes;
    private javax.swing.JButton searchRes;
    private javax.swing.JButton showSeats;
    // End of variables declaration//GEN-END:variables
}

Fall 2017 ITP 220 - V1 Java Programming II 
Project CheckPoint 3
Geoffrey Hicks

Step 1: Create a user in mySQL name ITP220, with the password also being ITP220. Be sure to give it access to every permission.

Step 2: Import the airlineMCAWS.sql file into mySQL

Step 3: Run java file!



drop database if exists Mcaws;

create database Mcaws;
use Mcaws;


drop table if exists FlightInformation;
drop table if exists customer;
drop table if exists pilot;
drop table if exists reservation;
drop table if exists deletedRes;

drop procedure if exists getAllCust;
drop procedure if exists addCust;
drop procedure if exists getCustId;
drop procedure if exists getSpecificCustId;
drop procedure if exists getFlightMatchFlightId;
drop procedure if exists getResSeatNum;
drop procedure if exists resInsertion;
drop procedure if exists checkIfFull;
drop procedure if exists getGroupAndSeat;
drop procedure if exists deleteRes;
drop procedure if exists getCustInfo;
drop procedure if exists getAllFlightInfo;
drop procedure if exists getFlightSum;
drop procedure if exists findRes;
drop procedure if exists deleteResUsingResNum;
drop procedure if exists displayRes;
drop procedure if exists updateDeletedRes;
drop procedure if exists getPilotFlight;
drop procedure if exists getCustRes;
drop procedure if exists getResRes;
drop procedure if exists getDeletedRes;
drop procedure if exists getDeletedResWithName;
drop procedure if exists getResCustSeatFC;
drop procedure if exists getResCustSeatEC;
drop procedure if exists resInsertionPrime;

  create table customer (
 custId int not null auto_increment,
 custName varchar(200),
 custAddress varchar(200),
 custPhone varchar(200),
 primary key (custId)
 
 );

 
 create table pilot (
 
 pilotId int not null auto_increment,
 pilotName varchar(200),
 primary key (pilotId)
 
 );
 
 create table FlightInformation (

flightId int not null auto_increment,
flightName varchar(100),
flightCode varchar(40),
flightDate varchar(40),
flightTime varchar(10), 
flightRoute varchar(100),
pilotNum int,
PRIMARY KEY (flightId),
foreign key (pilotNum) references pilot(pilotId)
 );
 
 create table reservation (

 reservationNum int not null auto_increment,
 custNumber int,
 flightSeat varchar(40),
 flightCost decimal (20,2),
 flightNumber int,
 groupNumber int,
 seatNumber int,
 PRIMARY KEY (reservationNum),
 foreign key (flightNumber) references FlightInformation(flightId),
 foreign key (custNumber) references customer(custId)
 
 
 );
 
 
insert into pilot (pilotId, pilotName) values (1, 'Sam Harris');
insert into pilot (pilotId, pilotName) values (2, 'Martha Stuart');
insert into pilot (pilotId, pilotName) values (3, 'John Brown' );

insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '12RPAM', 'November 12', 'AM', 'Roanoke to Phoenix', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '12PRAM', 'November 12', 'AM', 'Phoenix to Roanoke', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '12PRPM', 'November 12', 'PM', 'Phoenix to Roanoke', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '12RPPM', 'November 12', 'PM', 'Roanoke to Phoenix', 2);

insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '13RPAM', 'November 13', 'AM', 'Roanoke to Phoenix', 3);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '13PRAM', 'November 13', 'AM', 'Phoenix to Roanoke', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '13PRPM', 'November 13', 'PM', 'Phoenix to Roanoke', 3);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '13RPPM', 'November 13', 'PM', 'Roanoke to Phoenix', 1);
        
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '14RPAM', 'November 14', 'AM', 'Roanoke to Phoenix', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '14PRAM', 'November 14', 'AM', 'Phoenix to Roanoke', 3);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '14PRPM', 'November 14', 'PM', 'Phoenix to Roanoke', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '14RPPM', 'November 14', 'PM', 'Roanoke to Phoenix', 3);
        
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '15RPAM', 'November 15', 'AM', 'Roanoke to Phoenix', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '15PRAM', 'November 15', 'AM', 'Phoenix to Roanoke', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '15PRPM', 'November 15', 'PM', 'Phoenix to Roanoke', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '15RPPM', 'November 15', 'PM', 'Roanoke to Phoenix', 2);
        
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '16RPAM', 'November 16', 'AM', 'Roanoke to Phoenix', 3);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '16PRAM', 'November 16', 'AM', 'Phoenix to Roanoke', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '16PRPM', 'November 16', 'PM', 'Phoenix to Roanoke', 3);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '16RPPM', 'November 16', 'PM', 'Roanoke to Phoenix', 2);
        
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '17RPAM', 'November 17', 'AM', 'Roanoke to Phoenix', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '17PRAM', 'November 17', 'AM', 'Phoenix to Roanoke', 3);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '17PRPM', 'November 17', 'PM', 'Phoenix to Roanoke', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '17RPPM', 'November 17', 'PM', 'Roanoke to Phoenix', 3);
        
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '18RPAM', 'November 18', 'AM', 'Roanoke to Phoenix', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '18PRAM', 'November 18', 'AM', 'Phoenix to Roanoke', 1);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('A', '18PRPM', 'November 18', 'PM', 'Phoenix to Roanoke', 2);
insert into flightinformation (flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum) values ('B', '18RPPM', 'November 18', 'PM', 'Roanoke to Phoenix', 1);

insert into customer (custName, custAddress, custPhone) values ('Jerry Smith', '980 Example Drive', '4343829357');
insert into customer (custName, custAddress, custPhone) values ('Samantha Jones', '456 Example Drive', '4569083456');
insert into customer (custName, custAddress, custPhone) values ('Bridge Harris', '452 Example Drive', '4567890234');
insert into customer (custName, custAddress, custPhone) values ('Mule Jenkins', '234 Example Drive', '7890345678');
insert into customer (custName, custAddress, custPhone) values ('Big Smoke', '780 Example Drive', '1234567823');
insert into customer (custName, custAddress, custPhone) values ('Tommy Jones', '333 Example Drive', '4762349427');
insert into customer (custName, custAddress, custPhone) values ('Momma Patsi', '112 Example Drive', '3452673452');
insert into customer (custName, custAddress, custPhone) values ('Willy Wonka', '000 Example Drive', '3452784563');

insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (1, 'first class', 850, 1, 1, 1);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (2, 'first class', 850, 1, 1, 2);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (3, 'first class', 850, 1, 1, 3);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (4, 'first class', 850, 1, 1, 4);

insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (5, 'economy', 450, 7, 2, 1);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (4, 'economy', 450, 7, 2, 6);

insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (3, 'first class', 850, 14, 3, 1);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (1, 'first class', 850, 14, 3, 4);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (5, 'economy', 450, 14, 4, 4);
insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (2, 'economy', 450, 14, 4, 5);
 
  create table deletedRes (
deletedResID int not null auto_increment,
 reservationNum int not null,
 custNumber int,
 flightSeat varchar(40),
 flightCost decimal (20,2),
 flightNumber int,
 groupNumber int,
 seatNumber int,
 primary key (deletedResID),
 foreign key (flightNumber) references FlightInformation(flightId)
 );
 
 DELIMITER //

CREATE PROCEDURE getAllCust () 
BEGIN 
	select customer.* from customer;
END //

CREATE PROCEDURE addCust (IN myCustName varchar(80), myCustAddress varchar(100),  myCustPhone varchar(100))
BEGIN 
	insert into customer (custName, custAddress, custPhone) values (myCustName, myCustAddress, myCustPhone);
END //

CREATE PROCEDURE getCustId ()
BEGIN 
	select customer.custId from customer;
END //
 
CREATE PROCEDURE getSpecificCustId (IN myCustName varchar(100))
BEGIN 
	select customer.custId from customer where customer.custName = myCustName;
END //

CREATE PROCEDURE getFlightMatchFlightId (IN myFlightDate varchar(100), myFlightTime varchar(100), myFlightRoute varchar(100))
BEGIN 
	select flightId from flightinformation where flightDate = myFlightDate and flightTime = myFlightTime and flightRoute = myFlightRoute;
END //

CREATE PROCEDURE getResSeatNum (IN myFlightNum int, myfClass varchar(100))
BEGIN 
	select seatNumber from reservation where flightNumber = myFlightNum and flightSeat = myfClass;
END //

CREATE PROCEDURE resInsertion (IN myResNum int, myCustNum int, myfClass varchar(100), myFlightCost decimal(20,2),myFlightNumber int, myGroupNumber int, mySeatNumber int)
BEGIN 
	insert into reservation (reservationNum, custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (myResNum, myCustNum, myfClass, myFlightCost, myFlightNumber, myGroupNumber, mySeatNumber);
END //

CREATE PROCEDURE resInsertionPrime (IN myCustNum int, myfClass varchar(100), myFlightCost decimal(20,2),myFlightNumber int, myGroupNumber int, mySeatNumber int)
BEGIN 
	insert into reservation (custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber) values (myCustNum, myfClass, myFlightCost, myFlightNumber, myGroupNumber, mySeatNumber);
END //

CREATE PROCEDURE checkIfFull (IN myFlightNum int, myFlightSeat varchar(100))
BEGIN 
	select count(seatNumber) as seatCount from reservation where flightNumber = myFlightNum and flightSeat = myFlightSeat; 
END //

CREATE PROCEDURE getGroupAndSeat (IN myFlightNum int, myGroupNum int)
BEGIN 
	select groupNumber, seatNumber from reservation where flightNumber = myFlightNum and groupNumber = myGroupNum;
END //

CREATE PROCEDURE deleteRes (IN myGroupNum int)
BEGIN 
	delete from reservation where groupNumber = myGroupNum;
END //

CREATE PROCEDURE getCustInfo (IN myCustNum int)
BEGIN 
	select customer.custId, customer.custName, customer.custAddress, customer.custPhone from customer where customer.custId = myCustNum;
END //

CREATE PROCEDURE getAllFlightInfo ()
BEGIN 
	select count(*) as count from flightinformation;
END //

CREATE PROCEDURE getFlightSum (IN myFlightNum int)
BEGIN 
	select sum(flightCost) as totalFlightSum from reservation where flightNumber = myFlightNum;
END //

CREATE PROCEDURE findRes (IN resNum int)
BEGIN 
	select reservationNum from reservation where reservationNum = resNum;
END //

CREATE PROCEDURE deleteResUsingResNum (IN resNum int)
BEGIN 
	delete from reservation where reservationNum = resNum;
END //

CREATE PROCEDURE displayRes (IN resNum int)
BEGIN 
	select custNumber, flightCost, flightNumber, flightSeat, groupNumber, reservationNum, seatNumber from reservation where reservationNum = resNum;
END //

CREATE PROCEDURE updateDeletedRes (IN myCustNum int, myFlightCost decimal(20,2), myFlightNumber int, myFlightSeat varchar(40), myGroupNum int, myResNum int, mySeatNumber int) 
BEGIN 
	insert into deletedres (custNumber, flightCost, flightNumber, flightSeat, groupNumber, reservationNum, seatNumber) values (myCustNum, myFlightCost, myFlightNumber, myFlightSeat, myGroupNum, myResNum, mySeatNumber);
END //

CREATE PROCEDURE getPilotFlight (IN myPilotNum int) 
BEGIN 
	select flightId, flightName, flightCode, flightDate, flightTime, flightRoute, pilotNum from flightinformation where pilotNum = myPilotNum;
END //

CREATE PROCEDURE getCustRes (IN myCustNum int) 
BEGIN 
	select reservationNum, custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber from reservation where custNumber = myCustNum;
END //

CREATE PROCEDURE getResRes (IN myResNum int) 
BEGIN 
	select reservationNum, custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber from reservation where reservationNum = myResNum;
END //

CREATE PROCEDURE getDeletedRes (IN myResNum int) 
BEGIN 
	select reservationNum, custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber from deletedRes where reservationNum = myResNum;
END //

CREATE PROCEDURE getDeletedResWithName (IN myCustName varchar(80)) 
BEGIN 
	select reservationNum, custNumber, flightSeat, flightCost, flightNumber, groupNumber, seatNumber from deletedRes inner join customer on deletedRes.custNumber = customer.custId where customer.custName = myCustName;
END //

CREATE PROCEDURE getResCustSeatFC (IN flightChoice int) 
BEGIN 
	select custNumber, seatNumber from reservation where flightNumber = flightChoice and flightSeat = 'first class';
END //

CREATE PROCEDURE getResCustSeatEC (IN flightChoice int) 
BEGIN 
	select custNumber, seatNumber from reservation where flightNumber = flightChoice and flightSeat = 'economy';
END //



